var namespaces =
[
    [ "DDS", "namespaceDDS.html", null ]
];