var interfaceDDS_1_1IQueryCondition =
[
    [ "GetQueryExpression", "interfaceDDS_1_1IQueryCondition.html#a3b72d061a48614fb38f1d044747689b3", null ],
    [ "GetQueryParameters", "interfaceDDS_1_1IQueryCondition.html#a4a74f688dffb7f96321f25d4d578995c", null ],
    [ "SetQueryParameters", "interfaceDDS_1_1IQueryCondition.html#ac9ba35d3807e479d79a3109ee1e9d0c3", null ]
];