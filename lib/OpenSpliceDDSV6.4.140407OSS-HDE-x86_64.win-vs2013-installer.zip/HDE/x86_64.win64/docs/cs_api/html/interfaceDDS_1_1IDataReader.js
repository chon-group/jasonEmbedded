var interfaceDDS_1_1IDataReader =
[
    [ "CreateQueryCondition", "interfaceDDS_1_1IDataReader.html#acc8aef04c2856a77986781d6f8b03314", null ],
    [ "CreateQueryCondition", "interfaceDDS_1_1IDataReader.html#ae23801512b4dd7e7e0514208b85e8595", null ],
    [ "CreateReadCondition", "interfaceDDS_1_1IDataReader.html#aa4c8a1551824dd65db51f381318c7df1", null ],
    [ "CreateReadCondition", "interfaceDDS_1_1IDataReader.html#aa3ab7e7f7260f99d9702d4eb86a9b511", null ],
    [ "DeleteContainedEntities", "interfaceDDS_1_1IDataReader.html#a5657d88f4f3c9529e4e4dd49ff8a5bb1", null ],
    [ "DeleteReadCondition", "interfaceDDS_1_1IDataReader.html#add2130ab706c233c47eb7c4e2794f6ed", null ],
    [ "GetLivelinessChangedStatus", "interfaceDDS_1_1IDataReader.html#aea50c38cff04f603f1a5aaeb69687cb0", null ],
    [ "GetMatchedPublicationData", "interfaceDDS_1_1IDataReader.html#a809c7cc43a0ee2e37abc3dbf4bb80fa4", null ],
    [ "GetMatchedPublications", "interfaceDDS_1_1IDataReader.html#a3da21b38c68670136d4af57db6a44a35", null ],
    [ "GetQos", "interfaceDDS_1_1IDataReader.html#a47c11be1b34e1fb82203fa212a657942", null ],
    [ "GetRequestedDeadlineMissedStatus", "interfaceDDS_1_1IDataReader.html#a7d8f230be6b58c39a8d535b48655e024", null ],
    [ "GetRequestedIncompatibleQosStatus", "interfaceDDS_1_1IDataReader.html#ab820ecf621aebf04ee304d892ece0de6", null ],
    [ "GetSampleLostStatus", "interfaceDDS_1_1IDataReader.html#a2821f63076704a84382473f135dfc8a3", null ],
    [ "GetSampleRejectedStatus", "interfaceDDS_1_1IDataReader.html#a49df4d19af612949d4c2bebae57af9d2", null ],
    [ "GetSubscriptionMatchedStatus", "interfaceDDS_1_1IDataReader.html#ad0f395e0390808a22448e2513e2c95ce", null ],
    [ "GetTopicDescription", "interfaceDDS_1_1IDataReader.html#aaaf1b85f66b84fa8e854d7ba5eb64589", null ],
    [ "SetListener", "interfaceDDS_1_1IDataReader.html#a94f1e5925ba159fbb16335965874d56a", null ],
    [ "SetQos", "interfaceDDS_1_1IDataReader.html#acb4ca96bfbb1f70d8b0533fb7dd51af7", null ],
    [ "WaitForHistoricalData", "interfaceDDS_1_1IDataReader.html#a5d2864eb26273c752010becfd635e375", null ],
    [ "Subscriber", "interfaceDDS_1_1IDataReader.html#a6a5207511128c887c7203de62d574b1a", null ]
];