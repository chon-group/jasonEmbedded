var interfaceDDS_1_1IStatusCondition =
[
    [ "GetEnabledStatuses", "interfaceDDS_1_1IStatusCondition.html#a3609464aeb0baaba0167bf698edba9bb", null ],
    [ "GetEntity", "interfaceDDS_1_1IStatusCondition.html#add3d05dcf8840bbdb163f79d810691e8", null ],
    [ "SetEnabledStatuses", "interfaceDDS_1_1IStatusCondition.html#a379a50ceab56685e8fe1c8a8eb7bdba5", null ]
];