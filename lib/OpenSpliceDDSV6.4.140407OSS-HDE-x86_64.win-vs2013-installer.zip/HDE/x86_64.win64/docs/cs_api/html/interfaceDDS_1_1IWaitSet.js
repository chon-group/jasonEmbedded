var interfaceDDS_1_1IWaitSet =
[
    [ "AttachCondition", "interfaceDDS_1_1IWaitSet.html#a775069496c219baef1e339fa74483cd6", null ],
    [ "DetachCondition", "interfaceDDS_1_1IWaitSet.html#a47efc24ee7ece1cfe0e623f04cb9f347", null ],
    [ "GetConditions", "interfaceDDS_1_1IWaitSet.html#a136440c5509c7177c9cea43b4f0ecd66", null ],
    [ "Wait", "interfaceDDS_1_1IWaitSet.html#a4c91227dee1d2df4baefc22e9a2a0f13", null ]
];