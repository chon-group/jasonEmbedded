var annotated =
[
    [ "DDS", "namespaceDDS.html", "namespaceDDS" ]
];