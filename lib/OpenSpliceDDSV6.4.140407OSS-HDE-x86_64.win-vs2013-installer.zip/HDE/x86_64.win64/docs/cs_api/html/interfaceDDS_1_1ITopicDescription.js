var interfaceDDS_1_1ITopicDescription =
[
    [ "Name", "interfaceDDS_1_1ITopicDescription.html#a79861a00a0ac73d055c6b809d6f9c4b9", null ],
    [ "Participant", "interfaceDDS_1_1ITopicDescription.html#a504a393160a08a723e8c9555b5355749", null ],
    [ "TypeName", "interfaceDDS_1_1ITopicDescription.html#ab9a7fc55c34b72044ddef3879785439c", null ]
];