var interfaceDDS_1_1IEntity =
[
    [ "Enable", "interfaceDDS_1_1IEntity.html#ad9d3aa88052aa304cd12ee2e855f544e", null ],
    [ "InstanceHandle", "interfaceDDS_1_1IEntity.html#a6668f69bd9ee4cf5851bae35b3ae77f8", null ],
    [ "StatusChanges", "interfaceDDS_1_1IEntity.html#aa6d0f9ffc9cba64a8abaf593ec28831e", null ],
    [ "StatusCondition", "interfaceDDS_1_1IEntity.html#af6ec6716fad2f813037afac2e6de0cbf", null ]
];