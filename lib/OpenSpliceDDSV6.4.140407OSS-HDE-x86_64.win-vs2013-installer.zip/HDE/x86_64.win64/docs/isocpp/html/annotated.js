var annotated =
[
    [ "anonymous_namespace{implementation.cpp}", "namespaceanonymous__namespace_02implementation_8cpp_03.html", null ],
    [ "dds", "namespacedds.html", "namespacedds" ],
    [ "demo", "namespacedemo.html", "namespacedemo" ],
    [ "examples", "namespaceexamples.html", "namespaceexamples" ],
    [ "org", "namespaceorg.html", "namespaceorg" ],
    [ "ShapeType", "struct_shape_type.html", "struct_shape_type" ]
];