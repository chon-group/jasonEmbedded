var classdds_1_1core_1_1policy_1_1policy__name_3_01_ownership_strength_01_4 =
[
    [ "name", "classdds_1_1core_1_1policy_1_1policy__name_3_01_ownership_strength_01_4.html#a10eec69b3ff86cc5a1fee039b6733a78", null ]
];