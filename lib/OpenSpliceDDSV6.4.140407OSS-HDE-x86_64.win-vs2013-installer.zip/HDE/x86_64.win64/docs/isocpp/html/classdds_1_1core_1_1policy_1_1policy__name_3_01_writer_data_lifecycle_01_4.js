var classdds_1_1core_1_1policy_1_1policy__name_3_01_writer_data_lifecycle_01_4 =
[
    [ "name", "classdds_1_1core_1_1policy_1_1policy__name_3_01_writer_data_lifecycle_01_4.html#a118da575d612090b3a348ce9ec3a9111", null ]
];