var classdds_1_1core_1_1policy_1_1policy__name_3_01_ownership_01_4 =
[
    [ "name", "classdds_1_1core_1_1policy_1_1policy__name_3_01_ownership_01_4.html#ab77d27741863073013c95e7aee0fd2da", null ]
];