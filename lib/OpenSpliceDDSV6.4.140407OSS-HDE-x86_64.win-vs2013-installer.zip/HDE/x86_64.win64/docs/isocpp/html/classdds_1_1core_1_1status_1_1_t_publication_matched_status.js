var classdds_1_1core_1_1status_1_1_t_publication_matched_status =
[
    [ "TPublicationMatchedStatus", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a3fd2b07b583092ad9e86b7b1842d6ab3", null ],
    [ "current_count", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a95158c679328e72e872073508d14b971", null ],
    [ "current_count_change", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#aa65dd3a9a34561428bf3e3bff94516f2", null ],
    [ "delegate", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a8ec96261b909693b7345696101aada12", null ],
    [ "delegate", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#af2abae23fdc886af35667e0aefd9a7a2", null ],
    [ "last_subscription_handle", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a46c687b2a26063af5fd7918e7284a319", null ],
    [ "operator const D &", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#ae627046f0461e6d35d7ed864a8946f6a", null ],
    [ "operator D &", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#afaf76517febc957b35b316f8c06dcf12", null ],
    [ "operator!=", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a9bea3593f947b8d86a07f819e60e83bb", null ],
    [ "operator->", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a6cef4b7b7f27c3769c87489bc6b798f7", null ],
    [ "operator->", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a948a6f4576c26fe7e44c551a56f4d038", null ],
    [ "operator==", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a2dd6829015363c58a93d606d76205681", null ],
    [ "total_count", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a3a4f51a5377fed27ec4471c59d9ff6d2", null ],
    [ "total_count_change", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#af6f9f068452b6c19ecb9b36eb718746c", null ],
    [ "d_", "classdds_1_1core_1_1status_1_1_t_publication_matched_status.html#a524bb581d6961d26653838488712edf4", null ]
];