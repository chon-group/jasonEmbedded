var classdds_1_1core_1_1policy_1_1policy__id_3_01_ownership_01_4 =
[
    [ "value", "classdds_1_1core_1_1policy_1_1policy__id_3_01_ownership_01_4.html#a88b2f2b658c2414d1c61a3a13c56651b", null ]
];